chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "ma-ze-ai",
    title: "מה זה AI?",
    contexts: ["selection"]
  });
});

let apiKey = '';

async function loadSettings() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(["apiKey"], function(result) {
      apiKey = result.apiKey || "";
      resolve({ apiKey });
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "ma-ze-ai") {
    const selectedText = info.selectionText;
    await loadSettings();

    // שלח הודעה להצגת תיבת טוען
    chrome.tabs.sendMessage(tab.id, {
      action: "showExplanation",
      text: "טוען תשובה, אנא המתן..."
    }, async (response) => {
      // אם יש שגיאה – כלומר content.js לא פעיל בטאב הזה
      if (chrome.runtime.lastError) {
        console.warn("Content script לא קיים בטאב:", chrome.runtime.lastError.message);
        return;
      }

      // אחרי הצגת ההודעה, שלח את הבקשה ל־API
      try {
        const model = "gemini-2.0-flash";
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

        const response = await fetch(apiUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: "הסבר בקצרה מה זה " + selectedText
              }]
            }]
          })
        });

        if (!response.ok) {
          throw new Error("בעיה בשליחת בקשה לשרת");
        }

        const data = await response.json();
        const answer = data.candidates?.[0]?.content?.parts?.[0]?.text || "לא נמצאה תשובה.";

        chrome.tabs.sendMessage(tab.id, {
          action: "updateExplanation",
          text: answer
        });

      } catch (error) {
        console.error("שגיאה במהלך הבקשה:", error);
        chrome.tabs.sendMessage(tab.id, {
          action: "updateExplanation",
          text: "אירעה שגיאה בקבלת התשובה."
        });
      }
    });
  }
});
