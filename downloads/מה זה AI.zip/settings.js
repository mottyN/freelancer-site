document.addEventListener("DOMContentLoaded", function () {
    const apiKeyInput = document.getElementById("api-key");
    const saveButton = document.getElementById("save-settings");

    // טעינת ההגדרות השמורות באמצעות Chrome Storage API
    chrome.storage.local.get(["apiKey"], function(result) {
        apiKeyInput.value = result.apiKey || "";
    });
 

    // שמירת ההגדרות
    saveButton.addEventListener("click", function () {
        // שמירת ההגדרות באמצעות Chrome Storage API
        chrome.storage.local.set({
            apiKey: apiKeyInput.value,
        }, function() {
            // הצגת הפופ-אפ
            popup.style.display = "block";

            // הסתרת הפופ-אפ אחרי 5 שניות
            setTimeout(function() {
                popup.style.display = "none";
                // סגירת הדף אחרי 5 שניות
                window.close();
            }, 2000);
        });
    });
});
