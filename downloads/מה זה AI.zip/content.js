chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "showExplanation") {
     sendResponse({ success: true });
    // אם כבר קיימת — אל תיצור שוב
    if (document.getElementById("explanation-box")) return;

    // יצירת תיבת ההסבר
    const box = document.createElement("div");
    box.id = "explanation-box";

    const style = document.createElement("style");
    style.textContent = `
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);

    const closeButton = document.createElement("span");
    closeButton.innerText = "✖";
    Object.assign(closeButton.style, {
      position: "absolute",
      top: "5px",
      left: "10px",
      cursor: "pointer",
      fontWeight: "bold",
      fontSize: "16px"
    });
    closeButton.addEventListener("click", () => box.remove());

    const spinner = document.createElement("div");
    spinner.className = "spinner";
    Object.assign(spinner.style, {
      width: "24px",
      height: "24px",
      border: "4px solid #ccc",
      borderTop: "4px solid #333",
      borderRadius: "50%",
      animation: "spin 1s linear infinite",
      margin: "10px auto"
    });

    const text = document.createElement("div");
    text.id = "explanation-text";
    text.innerText = "אנא המתן...";

    Object.assign(box.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      background: "#fefefe",
      padding: "15px",
      borderRadius: "10px",
      boxShadow: "0 0 10px rgba(0,0,0,0.3)",
      zIndex: 9999,
      maxWidth: "300px",
      direction: "rtl",
      fontFamily: "sans-serif",
      textAlign: "center"
    });

    box.appendChild(closeButton);
    box.appendChild(spinner);
    box.appendChild(text);
    document.body.appendChild(box);
  }

  if (request.action === "updateExplanation") {
    const box = document.getElementById("explanation-box");
    if (!box) return;

    const spinner = box.querySelector(".spinner");
    const text = document.getElementById("explanation-text");
    if (spinner) spinner.remove();
    if (text) text.innerText = request.text;

    setTimeout(() => box.remove(), 15000);
  }
});
