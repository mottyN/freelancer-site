// תוסף ספירת העומר - קוד רקע
// יוצר התראה יומית בשעה 20:30 עם אפשרות לדחייה של דקה אחת

  // מאזין להתקנה והפעלה מחדש
chrome.runtime.onInstalled.addListener(() => {
    console.log("תוסף ספירת העומר הותקן.");
    scheduleDailyReminder();
  });
  
  chrome.runtime.onStartup.addListener(() => {
    console.log("תוסף ספירת העומר הופעל מחדש.");
    scheduleDailyReminder();
  });
  
  // מאזין להודעות מה-popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "remindLater") {
        console.log("נזכר מאוחר יותר נלחץ");
      // דוחה את ההתראה לדקה אחת
        
      chrome.alarms.create("remindLater", {
        delayInMinutes: 60 // דוחה את ההתראה ב-60 דקות
      });
    }
  });
  
  // מאזין להפעלת ההתראה
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "omerReminder") {
      // בדיקה אם כבר ספרת
      const todayStr = new Date().toISOString().split('T')[0];
      chrome.storage.local.get(`counted_${todayStr}`, (data) => {
        if (!data[`counted_${todayStr}`]) {
          chrome.notifications.create("omerReminder", {
            type: "basic",
            iconUrl: "icons/omer48.png",
            title: "הגיע הזמן לספירת העומר!",
            message: "זמן הספירה הגיע! אל תשכח לספור היום.",
            priority: 2
          });
        }
      });
    } else if (alarm.name === "remindLater") {
      // תמיד תציג את ההתראה - בלי לבדוק אם ספרת
      chrome.notifications.create("omerReminder", {
        type: "basic",
        iconUrl: "icons/omer48.png",
        title: "הזכורת המאוחרת שלך",
        message: "הבטחת שתספור מאוחר יותר. עכשיו זה הזמן 😊",
        priority: 2
      });
    }
  });
  // מאזין ללחיצה על התראה
chrome.notifications.onClicked.addListener((notificationId) => {
    if (notificationId === "omerReminder") {
      chrome.tabs.create({
        url: chrome.runtime.getURL("popup.html")
      });
    }
  });
  
  
  
  // תזכורת יומית קבועה בשעה 20:30
  function scheduleDailyReminder() {
    const now = new Date();
    const reminderTime = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      20, 30, 0, 0 // 20:30 בדיוק
    );
  
    if (reminderTime < now) {
      reminderTime.setDate(reminderTime.getDate() + 1);
    }
  
    chrome.alarms.create("omerReminder", {
      when: reminderTime.getTime()
    });
  
    console.log("תזכורת יומית נקבעה ל:", reminderTime.toLocaleString());
  }
  