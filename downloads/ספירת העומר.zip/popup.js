document.addEventListener('DOMContentLoaded', async () => {
    const countNowBtn = document.getElementById('count-now');
    const remindLaterBtn = document.getElementById('remind-later');
    const alreadyCountedBtn = document.getElementById('already-counted');
    const nusahSelect = document.getElementById('nusah-select');
    const safiraText = document.getElementById('safira-text');
    const safiraDisplay = document.getElementById('safira-display');
    const playAudioBtn = document.getElementById('play-audio');

    const today = new Date();

    // קבלת יום העומר הנוכחי (placeholder כרגע)
    const omerDay = getOmerDayByDate();
    if (omerDay) {
        // document.getElementById('current-day').textContent = getOmerText(omerDay);
    } else {
        document.getElementById('current-day').textContent = `לא בעונת הספירה`;
    }

    // document.getElementById('current-day').textContent = getOmerText(omerDay);

    countNowBtn.addEventListener('click', async () => {
        const nusah = nusahSelect.value;
        const text = getOmerText(omerDay);
        safiraText.textContent = text;
        safiraDisplay.style.display = 'block';
        saveAsCounted();
    });

    remindLaterBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'remindLater' });
        window.close();
    });

    alreadyCountedBtn.addEventListener('click', () => {
        saveAsCounted();
        window.close();
    });

    playAudioBtn.addEventListener('click', () => {
        const text = safiraText.textContent;
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "he-IL";
        speechSynthesis.speak(utterance);
    });

    function saveAsCounted() {
        const todayStr = today.toISOString().split('T')[0];
        chrome.storage.local.set({ [`counted_${todayStr}`]: true });
    }
    // navigator.geolocation.getCurrentPosition((pos) => {
    //     chrome.runtime.sendMessage({
    //       action: "setReminderWithLocation",
    //       coords: {
    //         lat: pos.coords.latitude,
    //         lon: pos.coords.longitude
    //       }
    //     });
    //   });
      
});

// דוגמת פונקציה לקבלת נוסח ספירה
async function getSefiratOmerText(day, nusah) {
    // אפשר להרחיב לפי נוסח, כרגע רק נוסח אחיד פשוט:
    const texts = {
        ashkenaz: `היום ${day} יום לעומר`,
        sfard: `היום ${day} ימים לעומר`,
        edot: `היום ${day} יום לעומר`
    };
    return texts[nusah] || texts.ashkenaz;
}

// דוגמה לפונקציה זמנית (נחליף אותה בשלב הבא!)
async function getOmerDay() {
    // נכניס לוגיקה מדויקת בהמשך עם לוח שנה עברי
    return 23; // לדוגמה, היום ה-23 לעומר
}

function getOmerDayByDate(date = new Date()) {
    const year = date.getFullYear();
  
    const pesachDates = {
      2024: new Date(2024, 3, 23),
      2025: new Date(2025, 3, 12),
      2026: new Date(2026, 3, 1),
      2027: new Date(2027, 2, 21),
      2028: new Date(2028, 3, 8),
      2029: new Date(2029, 2, 28),
      2030: new Date(2030, 3, 15),
      2031: new Date(2031, 3, 5),
      2032: new Date(2032, 2, 23),
      2033: new Date(2033, 3, 10),
      2034: new Date(2034, 2, 30),
      2035: new Date(2035, 2, 19),
      2036: new Date(2036, 3, 4),
      2037: new Date(2037, 2, 25),
      2038: new Date(2038, 3, 11),
      2039: new Date(2039, 2, 31),
      2040: new Date(2040, 2, 19),
      2041: new Date(2041, 3, 7),
      2042: new Date(2042, 2, 27),
      2043: new Date(2043, 3, 13),
    };
  
    const start = pesachDates[year];
    if (!start) return null;
  
    const omerStart = new Date(start);
    omerStart.setDate(start.getDate() + 1); // ט״ז ניסן
  
    const diffInMs = date - omerStart;
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
  
    if (diffInDays >= 0 && diffInDays < 49) {
      return diffInDays + 1;
    } else {
      return null;
    }
  }
  function getOmerText(day) {
    if (!day || day < 1 || day > 49) return "";
  
    const yomYamim = (n) => {
      if (n === 1) return "יום אחד";
      if (n === 2) return "שני ימים";
      if (n <= 10) return `${numberToWords(n)} ימים`;
      return `${numberToWords(n)} יום`;
    };
  
    const numberToWords = (n) => {
      const units = [
        "", "אחד", "שניים", "שלושה", "ארבעה", "חמישה", "שישה", "שבעה", "שמונה", "תשעה",
        "עשרה", "אחד עשר", "שנים עשר", "שלושה עשר", "ארבעה עשר", "חמישה עשר", "שישה עשר",
        "שבעה עשר", "שמונה עשר", "תשעה עשר"
      ];
      const tens = ["", "", "עשרים", "שלושים", "ארבעים"];
      if (n <= 19) return units[n];
      const ten = Math.floor(n / 10);
      const unit = n % 10;
      if (unit === 0) return tens[ten];
      return `${tens[ten]} ו${units[unit]}`;
    };
  
    const dayText = yomYamim(day);
    let text = `היום ${dayText} לעומר`;
  
    const weeks = Math.floor(day / 7);
    const remaining = day % 7;
  
    if (weeks > 0) {
      const weekText = (weeks === 1) ? "שבוע אחד" : `${numberToWords(weeks)} שבועות`;
      const dayPart = remaining > 0 ? ` ו${yomYamim(remaining)}` : "";
      text = `היום ${dayText} שהם ${weekText}${dayPart} לעומר`;
    }
  
    return text;
  }
  
