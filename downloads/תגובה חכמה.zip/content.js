// פונקציה לחילוץ כל הפוסטים מתוך רשימת הפוסטים


function extractAllPosts() {
    const postsContainer = document.querySelector('.posts.timeline.list-unstyled.mt-sm-2.p-0.py-3');
    if (!postsContainer) return [];

    const posts = postsContainer.querySelectorAll('li[component="post"]');
    return Array.from(posts).map(post => {
        const contentElement = post.querySelector('[component="post/content"]');
        return contentElement ? contentElement.innerText.trim() : '';
    }).filter(text => text.length > 0);
}

// פונקציה להוספת כפתור תגובה חכמה לפוסטים
function addAIReplyButton() {
    let post = document.querySelector('.d-flex.flex-row.p-2.text-bg-light.border.rounded.w-100.align-items-center');
    console.log('הוספת כפתור תגובה חכמה');
    document.querySelectorAll('.ai-reply-btn').forEach(btn => btn.remove());
    const button = document.createElement('button');
    button.innerText = 'תגובה חכמה 🤖';
    button.classList.add('ai-reply-btn');
    button.style.margin = '10px';

    button.onclick = async () => {
        let posts = extractAllPosts(); // חילוץ כל הפוסטים
        showPopup(); // הצגת הפופאפ עם ספינר
        let reply = await generateAIReplyGrok(posts);
        updatePopup(reply); // עדכון הפופאפ עם התגובה
    };

    post.appendChild(button);
}

function showPopup() {
    let popup = document.createElement('div');
    popup.id = 'ai-popup';
    popup.innerHTML = `
        <div class="popup-content">
            <span class="close-btn">&times;</span>
            <p>הבקשה נשלחה... אנא המתן</p>
            <div class="spinner"></div>
        </div>
    `;
    document.body.appendChild(popup);
    document.querySelector('.close-btn').onclick = () => popup.remove();
}

function updatePopup(reply) {
    let popup = document.getElementById('ai-popup');
    if (popup) {
        popup.querySelector('.popup-content').innerHTML = `
            <span class="close-btn">&times;</span>
            <p>${reply}</p>
        `;
        document.querySelector('.close-btn').onclick = () => popup.remove();
    }
}

// הוספת עיצוב עם CSS
const style = document.createElement('style');
style.innerHTML = `
    #ai-popup {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        text-align: center;
        max-width: 50vw;
        max-height: 50vh;
        overflow-y: auto;
    }
    .popup-content {
        position: relative;
    }
    .close-btn {
        position: absolute;
        top: 5px;
        right: 10px;
        cursor: pointer;
        font-size: 20px;
    }
    .spinner {
        border: 4px solid rgba(0, 0, 0, 0.1);
        border-left-color: #09f;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        animation: spin 1s linear infinite;
        margin: 10px auto;
    }
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);


window.addEventListener('load', async () => {
    await waitForPostsToLoad();
    addAIReplyButton(); // הוסף את כפתור התגובה החכמה

});



let topicNumber = null;
async function checkURLChange() {
    console.log('האזנה לשינויים ב-URL');
    console.log(topicNumber);
    
    if (topicNumber !== location.pathname.split('/')[2]) {
        topicNumber = location.pathname.split('/')[2];
        await waitForPostsToLoad();
        // addmm();
        addAIReplyButton();
    }
}

// האזנה לשינויים ב-URL כל חצי שנייה
setInterval(checkURLChange, 500);

// פונקציה שממתינה לטעינת הפוסטים לפני ההפעלה
async function waitForPostsToLoad() {
    return new Promise((resolve) => {
        const postsContainer = document.querySelector('.posts.timeline.list-unstyled.mt-sm-2.p-0.py-3');

        if (postsContainer && postsContainer.querySelectorAll('li[component="post"]').length > 0) {
            resolve();
            return;
        }

        // אם אין פוסטים, מאזינים לשינויים ב-DOM עד שהם נטענים
        const observer = new MutationObserver((mutations) => {
            const postsContainer = document.querySelector('.posts.timeline.list-unstyled.mt-sm-2.p-0.py-3');
            if (postsContainer && postsContainer.querySelectorAll('li[component="post"]').length > 0) {
                observer.disconnect(); // הפסק האזנה
                resolve(); // המשך הרצת הפונקציות
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
    });
}



//שימוש עם גרוק
let apiKey = '';
let model = '';
async function loadSettings() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get(["apiKey", "model"], function(result) {
            apiKey = result.apiKey || "";
            model = result.model || "";

            // if (apiKey === '') {
            //     alert('לא הוגדר מפתח API');
            //     reject('API Key is missing');
            // }
            // if (model === '') {
            //     alert('לא הוגדר מודל');
            //     reject('Model is missing');
            // }

            resolve({ apiKey, model });
        });
    });
}
async function generateAIReplyGrok(postText) {


    await loadSettings();
    if (apiKey === '') {
        // console.error('API Key is missing');
        alert('לא הוגדר מפתח API');
        return 'API Key is missing';
    }
    if (model === '') {
        // console.error('Model is missing');
        alert('לא הוגדר מודל');
        return 'Model is missing';
    }
    let title = document.querySelector('.topic-title').innerText;
    console.log(title);
    const url = 'https://api.groq.com/openai/v1/chat/completions';  // הכנס את ה-URL הנכון של Groq API

    const requestBody = {
        "messages": [
            {
                "role": "user",
                "content": postText + " צאט של כמה פוסטים כותרת הצאט " + title + "תן לי תגובה לפוסט הזה ותכתוב את זה בצורה של תגובה אנושית ובשפה העברית"  // כאן נשולח את הפוסט של המשתמש
            }
        ],
        "model": model  // שם המודל שבחרת
    };

    try {
        console.log('Sending request to Groq API...');

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,  // הכנס את ה-API Key שלך כאן
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        const data = await response.json();

        if (data.error) {
            console.error('Error:', data.error);
            return 'There was an error processing your request.';
        }

        console.log('Response:', data.choices[0].message.content);
        // const textArea = document.querySelector('textarea.write.shadow-none.rounded-1.w-100.form-control');
        // textArea.value = data.choices[0].message.content;
        // הצג את התשובה המתקבלת
        return data.choices[0].message.content || 'No response found';
    } catch (error) {
        console.error('Request failed', error);
        return 'There was an issue with the request.';
    }
}
// דוגמת שימוש:
// generateAIReplyGrok("מה דעתך על חתולים AI?").then(reply => console.log(reply));

// כאשר הכפתור נלחץ
// כאשר הכפתור נלחץ
// function addAIReply() {
//     let linka = null
//     document.querySelectorAll('a').forEach(link => {
//         if (link.href.includes('compose')) console.log(link); linka = link;
//     });
//     linka.addEventListener('click', function () {
//         // צור Observer שיחכה לשינויים במבנה ה-DOM
//         console.log('הכפתור נלחץ');

//         const observer = new MutationObserver(function (mutationsList, observer) {
//             // חפש את ה-textarea לפי class
//             const textArea = document.querySelector('textarea.write.shadow-none.rounded-1.w-100.form-control');
//             console.log(textArea);

//             if (textArea) {
//                 // הרכיב נמצא, הפעל את הקוד שלך
//                 console.log('ה-Textarea נטען');
//                 let posts = extractAllPosts(); // חלץ את כל הפוסטים
//                 console.log(posts); // הדפס את כל הפוסטים
//                 generateAIReplyGrok(posts[posts.length - 3] + posts[posts.length - 2] + posts[posts.length - 1]); // קרא לפונקציה שמקבלת פוסט ומחזירה תגו
//                 observer.disconnect(); // הפסק לעקוב אחרי השינויים
//             }
//         });

//         // הגדר את ה-Observer לעקוב אחרי שינויים ב-DOM
//         observer.observe(document.body, { childList: true, subtree: true });
//     });
// }
let cuonter = 0;
let observer = null

// function addmm() {
//     cuonter++
//     // console.log(cuonter+ "                367454567564575657897654324567897654");

//     let fleg = true
//     if (observer != null) observer.disconnect()
//     observer = new MutationObserver(function (mutationsList, observer) {
//         // חפש את ה-textarea לפי class
//         // console.log('שינוי בדף');

//         const textArea = document.querySelector('textarea.write.shadow-none.rounded-1.w-100.form-control');
//         console.log(textArea);
//         if (textArea && fleg) {
//             fleg = false
//             // הרכיב נמצא, הפעל את הקוד שלך
//             // console.log('ה-Textarea נטען');
//             let posts = extractAllPosts(); // חלץ את כל הפוסטים
//             // console.log(posts); // הדפס את כל הפוסטים
//             generateAIReplyGrok(posts); // קרא לפונקציה שמקבלת פוסט ומחזירה תגו
//             // הפסק לעקוב אחרי השינויים
//             observer.disconnect();

//         }
//     });

//     // הגדר את ה-Observer לעקוב אחרי שינויים ב-DOM
//     observer.observe(document.body, { childList: true, subtree: true });
// }