let isRequestInProgress = false;  // דגל המונע שליחה חוזרת של הבקשה

chrome.webRequest.onCompleted.addListener(
    function (details) {
        // נוודא שמדובר בבקשה ל-URL מסוים, למשל "cars.json"

        if (details.url.includes("cars.json")) {
            console.log("📩 תגובה חדשה מתקבלת מה-URL:", details.url);
            console.log(isRequestInProgress);

            if (isRequestInProgress === true) {
                isRequestInProgress = false; // סימון שהבקשה הסתיימה
                return;

            }
            isRequestInProgress = true; // סימון שהבקשה בתהליך

            // שלח בקשה חדשה לשרת כדי לקבל את הנתונים
            fetch(details.url)
                .then(response => response.json())
                .then(data => {
                    // שמור את הנתונים ב-local storage
                    chrome.storage.local.set({ carsData: data }, function () {
                        console.log("🚗 נתוני הרכבים נשמרו מחדש:", data);
                    });
                })
                .catch(error => console.error("שגיאה ב-fetch:", error))

        }
    },
    { urls: ["http://*/*", "https://*/*"] } // עקוב אחרי כל הבקשות לכל ה-URLs
);
