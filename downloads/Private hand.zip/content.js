// פונקציית הסתרת המודעות
k = false
function removeAgencyAds() {
    document.querySelectorAll('.feed-item-base_feedItemBox__5WVY1').forEach(ad => {
        if (!ad.classList.contains('private_scaleUpOnHover___hreC')) {
            ad.style.display = 'none'; // מסתיר מודעה מסוכנת
        }
    });
}
console.log("content.js נטען");

// יצירת תיבת סימון עם ה-SVG ותווית
function createCheckbox() {
    // יצירת תווית לתיבת הסימון
    const checkboxLabel = document.createElement('label');
    checkboxLabel.setAttribute('data-nagish', 'search-check-box-label');
    checkboxLabel.id = 'my-checkbox';

    // יצירת תיבת הסימון עצמה
    const checkboxInput = document.createElement('input');
    checkboxInput.type = 'checkbox';
    checkboxInput.setAttribute('data-nagish', 'search-check-box-input');

    // יצירת תווית טקסט ליד תיבת הסימון
    const span = document.createElement('span');
    span.textContent = 'ללא מודעות מסוכנויות';

    // חיבור תיבת הסימון ותגית הטקסט לתווית
    checkboxLabel.appendChild(checkboxInput);
    checkboxLabel.appendChild(span);

    // מציאת האובייקט אליו יש להוסיף את תיבת הסימון
    const container = document.querySelector('.ad-characteristics-layout_checkboxesGroupBox__LYWL9');
    if (container) {
        container.appendChild(checkboxLabel);
    }

    // להאזין לשינויי מצב התיבה
    checkboxInput.addEventListener('change', () => {
        if (checkboxInput.checked) {
            // removeAgencyAds(); // מסתיר את המודעות אם התיבה מסומנת
            k = true
        } else {
            document.querySelectorAll('.feed-item-base_feedItemBox__5WVY1').forEach(ad => {
                // ad.style.display = ''; // מחזיר את הצגת המודעות
                k = false
            });
        }
    });
}
// חיפוש אחר הכפתור עם ה-attribute data-nagish="search-submit-button"
const searchButton = document.querySelector('button[data-nagish="search-submit-button"]');

// אם הכפתור נמצא, נרשום לו מאזין לאירוע click
if (searchButton) {
    searchButton.addEventListener('click', () => {
        // אם הכפתור נלחץ, נבצע את הסינון
        // console.log("sfrgrff");
        // console.log(k);
        // addKmToAds();

        const checkboxInput = document.querySelector('#my-checkbox');

        if (checkboxInput && checkboxInput.checked || k) {
            // console.log("kjhcfcgv");

            removeAgencyAds(); // הסתיר את המודעות אם תיבת הסימון מסומנת
        } else {
            document.querySelectorAll('.feed-item-base_feedItemBox__5WVY1').forEach(ad => {
                ad.style.display = ''; // החזר את הצגת המודעות
            });
        }
    });
}

window.addEventListener("load", function() {
    addKmToAds();
});


// נוודא שהאלמנט שאליו נוסיף את תיבת הסימון קיים
const observer = new MutationObserver(() => {
    const container = document.querySelector('.ad-characteristics-layout_checkboxesGroupBox__LYWL9');
    if (container) {

    }

    if (container && !document.querySelector('#my-checkbox')) {
        createCheckbox(); // אם האלמנט קיים, נוסיף את תיבת הסימון

    }
});

// התחל לעקוב אחרי שינויים ב-DOM
observer.observe(document.body, { childList: true, subtree: true });

// לטפל במודעות חדשות שמתווספות (למשל בגלילה)
const observerAds = new MutationObserver(() => {
    // addKmToAds();
    const checkboxInput = document.querySelector('#my-checkbox');
    if (checkboxInput && checkboxInput.checked || k) {
        removeAgencyAds();
        // שליפה של הנתונים ששמרת ב-local storage


    }
});
observerAds.observe(document.body, { childList: true, subtree: true });


// הוספת ק"מ לרשימת המודעות
function addKmToAds(adJson) {

    chrome.storage.local.get("carsData", function (result) {
        if (!result.carsData) {
            // console.log("❌ לא נמצאו נתונים ב-local storage");
            return;
        }

        // שמירת הנתונים מה-local storage
        const carsData = result.carsData.pageProps.dehydratedState.queries[0].state.data;
        // console.log("🚗 נתוני הרכבים שהושגו:", carsData);

        // מוצא את כל הדיבים של המודעות
        const adDivs = document.querySelectorAll('.feed-item-base_feedItemBox__5WVY1');
        // console.log(adDivs);
        // עובר על כל דיב
        adDivs.forEach(adDiv => {
            // מוציא את הטוקן מהקישור בתוך הדיב
            const token = adDiv.querySelector('a').href.split('?')[0].split('/').pop();
            // console.log(`🔍 מחפש טוקן: ${token}`);

            // מחפש את המודעה בתוך כל אחת מהקטגוריות: platinum, boost, solo, commercial, private
            let carData;

            // בודק כל קטגוריה בתוך ה-carsData
            ['platinum', 'boost', 'solo', 'commercial', 'private'].forEach(category => {
                if (!carData && carsData[category]) {
                    carData = carsData[category].find(car => car.token === token);
                }
            });

            if (carData) {
                // console.log(`✅ נמצא רכב תואם לטוקן ${token}:`, carData);

                // מוסיף את המידע על הק"מ לדיב
                if (adDiv.querySelector('.ad-km')) {
                    return;
                }
                const kmElement = document.createElement('span');
                kmElement.classList.add('ad-km');
                kmElement.textContent = `ק"מ: ${carData.km}`;

                // מוסיף את המידע על הק"מ לדיב
                adDiv.appendChild(kmElement);
            } else {
                // console.log(`⚠️ לא נמצא מידע לטוקן ${token}`);
                const link = adDiv.querySelector('a').href;
                // console.log(link);

                fetch(link)
                    .then(response => response.text())
                    .then(data => {
                        // console.log(data);

                        const parser = new DOMParser();
                        const htmlDocument = parser.parseFromString(data, 'text/html');
                        // const km = htmlDocument.querySelector('.ad-text-details').textContent.split(" ")[0];
                        // console.log(km);
                        // const kmElement = htmlDocument.querySelector('span[data-testid="term"] + span.details-item_itemValue__r0R14');
                        // const kmValue = kmElement ? kmElement.textContent.replace(/\D/g, '') : null;
                        const allBoxes = [...htmlDocument.querySelectorAll('.details-item_detailsItemBox__blPEY')];
                        // console.log(allBoxes); // ראה איזה אלמנטים נמצאים
                        
                        const kmBox = allBoxes.find(el => el.textContent.includes('ק״מ'));
                        // console.log(kmBox); // בדוק אם נמצא האלמנט הנכון
                        
                        const kmElement1 = kmBox ? kmBox.querySelector('span[data-testid="term"]') : null;
                        // console.log(kmElement); // בדוק אם נמצא ה-span הנכון
                        
                        const kmValue = kmElement1 ? kmElement1.textContent : null;

                        // console.log(kmValue); // יראה את הק"מ בלי תווים לא מספריים

                        const kmElement = document.createElement('span');
                        kmElement.classList.add('ad-km');
                        let km1 = kmValue != null ? kmValue : 0;
                        kmElement.textContent = `ק"מ: ${km1}`;
                        adDiv.appendChild(kmElement);
                    })
                    .catch(error => console.error("שגיאה ב-fetch:", error))
            }
        });
    });
}


chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === "local" && changes.carsData) {
        console.log("🔄 נתוני המכוניות התעדכנו ב-storage - מפעיל addKmToAds");
        addKmToAds();
    }
});
